"""Isolated MASPO compatibility reference, never a mathematical certificate.
Source: wangzx1219/MASPO @90e8c6fcc08c1e8f9a61740b296d4fab9e09e2d2 utils.py.
Only two pure functions are transplanted; no model/client code is imported.
"""
import re
import html

def extract_answer(raw: str) -> str:
    raw = raw.strip()
    for _ in range(3):
        new_raw = html.unescape(raw)
        if new_raw == raw:
            break
        raw = new_raw

    matches = re.findall(r"<answer>(.*?)</answer>", raw, re.S)
    if matches:
        return matches[-1].strip()

    box_pat = re.compile(r"\\boxed\s*\{((?:[^{}]|\{[^{}]*\})*)\}", re.S)
    m = box_pat.search(raw)
    if m:
        return m.group(1).strip()

    sentences = re.split(r'[。\n;]+', raw)
    last = sentences[-1].strip()
    return last[-30:] if len(last) > 30 else last

def normalize_answer(answer: str) -> str:
    answer = answer.strip()
    answer = re.sub(r'\$(.*?)\$', r'\1', answer)
    answer = re.sub(r'\\\[(.*?)\\\]', r'\1', answer, flags=re.S)
    answer = re.sub(r'\\text\{([^}]*)\}', r'\1', answer)
    answer = re.sub(r'\\boxed\s*{((?:[^{}]|{[^}]*})*?)}', r'\1', answer)
    answer = re.sub(r'\\\((.*?)\\\)', r'\1', answer)
    answer = re.sub(r'\\?°', '', answer)
    answer = re.sub(r'\^?\\?circ', '', answer)
    answer = re.sub(r'\s+', '', answer)
    answer = re.sub(r'\\sqrt\s*{([^}]*)}', r'sqrt(\1)', answer)
    answer = re.sub(r'√(\d+)', r'sqrt(\1)', answer)
    answer = re.sub(r'\\frac\{([^}]+)\}\{([^}]+)\}', r'\1/\2', answer)
    answer = re.sub(r'\\dfrac\{([^}]+)\}\{([^}]+)\}', r'\1/\2', answer)
    answer = re.sub(r'\\pi', 'π', answer)
    answer = re.sub(r'\\left|\\right', '', answer)
    answer = answer.replace('[', '(').replace(']', ')')
    if re.fullmatch(r'[,\s\-0-9]+', answer):
        nums = [int(x) for x in re.findall(r'-?\d+', answer)]
        return ','.join(map(str, sorted(nums)))
    return answer.lower()
