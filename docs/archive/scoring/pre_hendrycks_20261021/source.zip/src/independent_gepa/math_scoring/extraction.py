"""Bounded, gold-blind declaration parser; no symbolic imports or policy branches."""
from dataclasses import dataclass
import re

@dataclass(frozen=True)
class Extraction:
    payload:str=''
    valid:bool=False
    reason:str='MISSING_EXPLICIT_FINAL_ANSWER'
    source:str='none'

def balanced(text,max_nesting=32):
    stack=[]
    for i,c in enumerate(text):
        if i and text[i-1]=='\\':continue
        if c=='{':
            stack.append(c)
            if len(stack)>max_nesting:return False
        elif c=='}':
            if not stack:return False
            stack.pop()
    return not stack

def boxes(text,max_nesting=32):
    result=[]
    for m in re.finditer(r'\\boxed\s*\{',text):
        depth=1;end=m.end()
        while end<len(text) and depth:
            c=text[end]
            if not end or text[end-1]!='\\':
                if c=='{':depth+=1
                elif c=='}':depth-=1
            if depth>max_nesting:return [],'NESTING_LIMIT'
            end+=1
        if depth:return [],'UNCLOSED_BOX'
        # Nested boxes are part of their enclosing expression, not competing finals.
        if not result or m.start()>=result[-1][1]:result.append((m.start(),end,text[m.end():end-1]))
    return result,None

def normalize_surface(text):
    """Remove display-only syntax, preserving containers/order/signs/case/names."""
    s=text.strip()
    for _ in range(32):
        previous=s
        for left,right in [('$$','$$'),('$','$'),(r'\[',r'\]'),(r'\(',r'\)'),('`','`')]:
            if s.startswith(left) and s.endswith(right) and len(s)>len(left)+len(right):s=s[len(left):-len(right)].strip();break
        b,reason=boxes(s)
        if not reason and b and b[0][0]==0 and b[0][1]==len(s):s=b[0][2].strip()
        if s==previous:break
    s=re.sub(r'\\(?:left|right|big|Big|bigg|Bigg|displaystyle)\b','',s)
    s=re.sub(r'\\(?:dfrac|tfrac)\b',lambda m:r'\frac',s)
    s=re.sub(r'\\(?:[,!;:]|quad\b|qquad\b|enspace\b|thinspace\b)',' ',s)
    # Preserve separators between alphanumeric tokens (e.g. "1 2" != "12").
    s=re.sub(r'\s+',' ',s).strip()
    s=re.sub(r'(?<=[^A-Za-z0-9])\s+|\s+(?=[^A-Za-z0-9])','',s)
    return s

def _payload(value,policy):
    s=value.strip()
    if s.startswith('```'):
        lines=s.splitlines()
        if len(lines)<3 or lines[-1].strip()!='```':return None,'UNCLOSED_MATH_FENCE'
        s='\n'.join(lines[1:-1]).strip()
    # A complete leading box supplies an exact boundary before trailing prose.
    b,reason=boxes(s,policy.max_nesting)
    if reason:return None,reason
    if b and b[0][0]==0:
        tail=s[b[0][1]:].strip()
        if not tail or re.match(r'^(?:[.;]|because\b|which\b|where\b)',tail,re.I):s=b[0][2]
    s=normalize_surface(s)
    # Complete math display followed by explanation has a clear syntactic boundary.
    for left,right in [('$','$'),(r'\[',r'\]'),(r'\(',r'\)')]:
        if s.startswith(left):
            end=s.find(right,len(left))
            if end>=0 and s[end+len(right):].strip():s=normalize_surface(s[:end+len(right)])
    if s.endswith('.') and not re.search(r'\d\.\d+$',s):s=s[:-1].rstrip()
    if not s:return None,'EMPTY_FINAL_DECLARATION'
    if len(s)>policy.max_expression_characters:return None,'EXPRESSION_LENGTH_LIMIT'
    if not balanced(s,policy.max_nesting) or s.count('$')%2:return None,'MALFORMED_FINAL_BOUNDARY'
    if re.search(r'<\s*/?\s*answer\b',s,re.I):return None,'MALFORMED_ANSWER_TAG'
    # Reject obvious prose without trying to mathematically parse an expression.
    prose=re.sub(r'\\(?:text|mathrm|operatorname)\{[^{}]*\}','',s)
    if re.search(r'\b(?:or|and|either|versus)\b',prose,re.I):return None,'AMBIGUOUS_FINAL_PAYLOAD'
    if re.search(r'\b[A-Za-z]{3,}\s+[A-Za-z]{3,}\b',prose):return None,'FINAL_PAYLOAD_CONTAINS_PROSE'
    return s,None

def extract_final(raw,finish_reason,policy):
    if finish_reason!='stop':return Extraction(reason='OUTPUT_TRUNCATED' if finish_reason in ['length','max_tokens','max_output_tokens'] else 'UNSUPPORTED_FINISH_REASON')
    if not isinstance(raw,str):return Extraction(reason='PREDICTION_NOT_TEXT')
    if len(raw)>policy.max_raw_characters:return Extraction(reason='RAW_LENGTH_LIMIT')
    tags=list(re.finditer(r'<answer>(.*?)</answer>',raw,re.S|re.I))
    if len(re.findall(r'<answer>',raw,re.I))!=len(tags) or len(re.findall(r'</answer>',raw,re.I))!=len(tags):return Extraction(reason='UNCLOSED_ANSWER_TAG')
    declarations=[]
    for m in tags:declarations.append((m.start(),m.end(),m[1],'tag'))
    lines=list(re.finditer(r'[^\r\n]+',raw));skip=-1
    for i,line in enumerate(lines):
        if i<=skip or any(a<=line.start()<b for a,b,_,_ in declarations):continue
        content=re.sub(r'^\s*(?:#{1,6}\s+|[-*+]\s+|\d+[.)]\s+)','',line[0]).strip()
        content=re.sub(r'^\*\*|^__','',content)
        label=re.match(r'^(?:final[ _]+answer|answer)\s*(?:\*\*|__)?\s*[:=]\s*(.*)$',content,re.I)
        conclusion=re.match(r'^(?:(?:therefore|thus|hence|so)[,:]?\s+(?:(?:the\s+)?(?:final\s+)?(?:answer|result)\s+is\s*:?\s+)?|(?:the\s+)?(?:final\s+)?answer\s+is\s*:?\s+)(.+)$',content,re.I)
        if not label and not conclusion:continue
        value=label[1] if label else conclusion[1]
        next_line=lines[i+1][0].strip() if i+1<len(lines) else ''
        if label and not value.strip() and re.match(r'^(?:final[ _]+answer|answer)\s*[:=]|^<answer>',next_line,re.I):continue
        # A conclusion may introduce an immediately following complete display.
        # Its prose is a boundary marker, never part of the mathematical payload.
        display_intro=not label and value.rstrip().endswith(':') and next_line.startswith((r'\[','$$',r'\boxed{','```'))
        if not label and not display_intro and not re.search(r'\d|=|\\[A-Za-z]|^[A-Za-z]$',value.strip()):continue
        value=re.sub(r'^(?:\*\*|__)\s*','',value)
        if value.endswith(('**','__')):value=value[:-2].rstrip()
        j=i
        if display_intro:j+=1;value=lines[j][0].strip()
        while (not value.strip() or not balanced(value,policy.max_nesting) or (value.lstrip().startswith((r'\[','$$','```')) and not value.rstrip().endswith((r'\]','$$','```')))) and j+1<len(lines):
            j+=1;value+='\n'+lines[j][0].strip()
            if len(value)>policy.max_expression_characters*2:break
        skip=j
        if label and not value.strip():continue
        declarations.append((line.start(),lines[j].end(),value,'label' if label else 'conclusion'))
    b,reason=boxes(raw,policy.max_nesting)
    if reason:return Extraction(reason=reason)
    for start,end,payload in b:
        if any(a<=start<z and kind in ('tag','label') for a,z,_,kind in declarations):continue
        # Unmarked intermediate boxes do not become final declarations. A final
        # box may be inline with prose before it and punctuation after it.
        if re.fullmatch(r'(?:\s|\\\]|\\\)|\$|```|\*\*|__|[.;])*',raw[end:]):declarations.append((start,end,payload,'box'))
    if not declarations:return Extraction()
    strong=[d for d in declarations if d[3] in ('tag','label')]
    if strong:
        boundary=max(d[0] for d in strong)
        # Explicit labels/tags are final claims. Earlier natural conclusions
        # belong to reasoning; only later confirmations can conflict with them.
        declarations=[d for d in declarations if d[3] in ('tag','label') or d[0]>boundary]
    else:
        # An unlabelled conclusion in the middle of later work is not a final
        # declaration. A terminal box can override the surrounding prose; an
        # unexplained later region must never fall back to an earlier result.
        declarations=[d for d in declarations if d[3]!='conclusion' or re.fullmatch(r'(?:\s|\\\]|\\\)|\$|```|\*\*|__|[.;])*',raw[d[1]:])]
        if not declarations:return Extraction()
        # With no explicit label/tag, only the last deterministic conclusion or
        # terminal box is the final region, never an earlier working conclusion.
        declarations=[max(declarations,key=lambda d:d[0])]
    if len(declarations)>policy.max_declarations:return Extraction(reason='DECLARATION_LIMIT')
    declarations.sort(key=lambda v:v[0]);parsed=[]
    for a,b,value,source in declarations:
        payload,error=_payload(value,policy)
        if error:return Extraction(reason=error,source=source)
        parsed.append((payload,source))
    if len({normalize_surface(p) for p,_ in parsed})!=1:return Extraction(reason='CONFLICTING_FINAL_ANSWERS',source='multiple')
    return Extraction(parsed[-1][0],True,'EXPLICIT_FINAL_DECLARATION',parsed[-1][1])
