"""Reuse the unchanged pinned local kernel; never import the sibling repository."""
def load():
    from ..math_comparison import math_domain_worker as kernel
    kernel.initialize()
    return kernel

def normalize_native_input(value):
    from ..single_prompt_math.math_flexible_answer import normalize_payload
    return normalize_payload(value)

def dependency_sources():
    from pathlib import Path
    base=Path(__file__).parents[1]
    return {"kernel":base/"math_comparison/math_domain_worker.py","settings":base/"math_comparison/contract.py","normalization":base/"single_prompt_math/math_flexible_answer.py"}
