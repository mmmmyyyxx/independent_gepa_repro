"""Complete versioned identities; no implicit production/default policy."""
from dataclasses import dataclass,asdict
from hashlib import sha256
import json
from pathlib import Path
from functools import lru_cache
import ast

PINS={'math-verify':'0.6.0','sympy':'1.14.0','latex2sympy2_extended':'1.0.9',
      'antlr4-python3-runtime':'4.13.2','mpmath':'1.3.0'}
MASPO_COMMIT='90e8c6fcc08c1e8f9a61740b296d4fab9e09e2d2'
POLICIES=('paper_extracted_exact_v1','maspo_compat_v1','math_semantic_v1')
def digest(value):
    return sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')).hexdigest()

@lru_cache(maxsize=128)
def _file_digest(path,mtime_ns,size):return sha256(Path(path).read_bytes()).hexdigest()
def component_hashes():
    parent=Path(__file__).parent;out={}
    for name in ['policy.py','extraction.py','compat_maspo.py','semantic.py','supervisor.py','worker.py','api.py']:
        path=parent/name;stat=path.stat();out[name]=_file_digest(str(path),stat.st_mtime_ns,stat.st_size)
    from .kernel_binding import dependency_sources
    for name,path in dependency_sources().items():
        stat=path.stat();out['pinned_local_'+name]=_legacy_digest(str(path),stat.st_mtime_ns,stat.st_size,name)
    return out

@lru_cache(maxsize=32)
def _legacy_digest(path,mtime_ns,size,kind):
    # Bind reused mathematics/presentation code while ignoring repository-local
    # imports and unrelated historical entrypoints that are never called here.
    names={'kernel':{'initialize','parse_payload','verify_payload','compatible','ambiguous_parentheses'},'normalization':{'normalize_payload'}}
    tree=ast.parse(Path(path).read_text(encoding='utf-8'))
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names.get(kind,set())]
    if kind=='settings':
        nodes=[n for n in tree.body if isinstance(n,(ast.Assign,ast.AnnAssign)) and 'SETTINGS' in ast.unparse(n).split('=',1)[0]]
        class LiteralDict(ast.NodeTransformer):
            def visit_Call(self,node):
                if not isinstance(node.func,ast.Name) or node.func.id!='dict' or node.args or any(k.arg is None for k in node.keywords):raise RuntimeError('NONLITERAL_PINNED_SETTINGS')
                return ast.Dict(keys=[ast.Constant(k.arg) for k in node.keywords],values=[self.visit(k.value) for k in node.keywords])
        settings={}
        for node in nodes:
            target=node.targets[0] if isinstance(node,ast.Assign) else node.target
            value=ast.literal_eval(LiteralDict().visit(node.value))
            if isinstance(target,ast.Name):settings=value
            elif isinstance(target,ast.Subscript):settings[ast.literal_eval(target.slice)]=value
            else:raise RuntimeError('UNSUPPORTED_PINNED_SETTINGS_ASSIGNMENT')
        return digest(settings)
    if not nodes:raise RuntimeError('PINNED_LOCAL_COMPONENT_NOT_FOUND')
    def canonical(node):
        if isinstance(node,ast.AST):
            return [type(node).__name__,{name:canonical(value) for name,value in ast.iter_fields(node)
                if not (name=='type_params' and value==[])}]
        if isinstance(node,list):return [canonical(value) for value in node]
        return node
    # Python3.12 adds empty type_params to ordinary functions. It carries no
    # scientific meaning and cannot change identity between the pinned runtimes.
    return digest([canonical(n) for n in nodes])

@dataclass(frozen=True)
class Policy:
    policy_id:str
    extraction_id:str='MATH_GOLD_BLIND_DECLARATIONS_V1'
    normalization_id:str='MATH_PRESENTATION_ONLY_V1'
    semantic_id:str='MATH_TYPED_PINNED_KERNEL_V1'
    max_raw_characters:int=65536
    max_expression_characters:int=2048
    max_nesting:int=32
    max_declarations:int=32
    max_container_items:int=32
    max_expression_nodes:int=512
    max_integer_digits:int=256
    max_literal_exponent:int=10000
    wall_seconds:float=8.0
    startup_seconds:float=10.0
    memory_megabytes:int=1024
    cache_entries:int=4096
    def __post_init__(self):
        if self.policy_id not in POLICIES:raise ValueError('UNKNOWN_SCORING_POLICY')
        for name in ('max_raw_characters','max_expression_characters','max_nesting','max_declarations',
            'max_container_items','max_expression_nodes','max_integer_digits','max_literal_exponent','memory_megabytes','cache_entries'):
            if type(getattr(self,name)) is not int or getattr(self,name)<=0:raise ValueError('INVALID_POLICY_LIMIT')
        if not 0<self.wall_seconds<=8 or not 0<self.startup_seconds<=10:raise ValueError('UNBOUNDED_POLICY_DEADLINE')
        if self.max_raw_characters>65536 or self.max_expression_characters>4096 or self.memory_megabytes>2048:raise ValueError('UNBOUNDED_POLICY_RESOURCES')
    def identity(self):
        return dict(**asdict(self),dependencies=PINS,scoring_component_sha256=component_hashes(),maspo_source_commit=MASPO_COMMIT,
            comparison_direction='gold_first_prediction_second',vote='separate_symmetric_both_directions',
            finish_reason='stop_only_except_original_MASPO_reference_semantics',
            unresolved_correct=None,normalization='no_interval_conversion_no_casefold_no_sort_no_algebra',
            semantic_kernel='pinned_existing_worker_math_verify_no_fallback; explicit_typed_containers; no_new_power_certificates',
            kernel_internal_timeout='disabled_only_in_supervised_child; external_wall_and_memory_limits',
            two_component_parentheses='ambiguous_without_explicit_frozen_type_hint; never_infer_from_gold_match',
            computational_failure='one_attempt_return_typed_unknown_no_model_sampling',
            maspo='isolated_original_extraction_and_normalization_reference_only_not_shared_extractor')
    @property
    def sha256(self):return digest(self.identity())
def policy_for(policy_id,**limits):return Policy(policy_id,**limits)
