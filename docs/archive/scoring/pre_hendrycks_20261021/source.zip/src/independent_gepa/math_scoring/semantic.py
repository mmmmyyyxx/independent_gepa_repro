"""Typed bounded comparison; arithmetic is exact Fraction or pinned Math-Verify."""
from fractions import Fraction
from functools import lru_cache
import re
from .extraction import normalize_surface,balanced

class Unsupported(ValueError):pass
class BadReference(ValueError):pass
_KERNEL=None
COUNTS={'parse':0,'verify':0}
def kernel():
    global _KERNEL
    if _KERNEL is None:
        from .kernel_binding import load
        _KERNEL=load()
    return _KERNEL

def split_top(text,separator=','):
    stack=[];parts=[];start=0
    for i,c in enumerate(text):
        if c in '({[':stack.append(c)
        elif c in ')}]':
            if not stack:raise Unsupported('UNBALANCED_CONTAINER')
            stack.pop()
        elif c==separator and not stack:parts.append(text[start:i].strip());start=i+1
    if stack:raise Unsupported('UNBALANCED_CONTAINER')
    parts.append(text[start:].strip());return parts

def single_outer_pair(text):
    depth=0
    for i,c in enumerate(text):
        if c in '([{':depth+=1
        elif c in ')]}':depth-=1
        if depth==0 and i<len(text)-1:return False
    return depth==0

def typed(text,policy,depth=0):
    s=normalize_surface(text)
    if not s or not balanced(s,policy.max_nesting):raise Unsupported('MALFORMED_EXPRESSION')
    if len(s)>policy.max_expression_characters or depth>policy.max_nesting:raise Unsupported('EXPRESSION_RESOURCE_LIMIT')
    if re.search(r'[`";]|__|\\(?:input|include|write|def|newcommand)\b',s):raise Unsupported('UNSUPPORTED_EXPRESSION_SYNTAX')
    if any(len(x)>policy.max_integer_digits for x in re.findall(r'\d+',s)):raise Unsupported('INTEGER_DIGIT_LIMIT')
    for m in re.finditer(r'(?:\^|\*\*)\s*\{?\s*([+-]?\d+)',s):
        if abs(int(m[1]))>policy.max_literal_exponent:raise Unsupported('LITERAL_EXPONENT_LIMIT')
    for m in re.finditer(r'(?:\^|\*\*)\s*\{?\s*\\frac\{([+-]?\d+)\}\{([+-]?\d+)\}',s):
        if int(m[2])==0:raise Unsupported('ZERO_DENOMINATOR')
        if abs(Fraction(int(m[1]),int(m[2])))>policy.max_literal_exponent:raise Unsupported('LITERAL_FRACTIONAL_EXPONENT_LIMIT')
    if len(re.findall(r'\\[A-Za-z]+|\d+|[A-Za-z]+|[^\s]',s))>policy.max_expression_nodes:raise Unsupported('LEXICAL_COMPLEXITY_LIMIT')
    matrix=re.fullmatch(r'\\begin\{(matrix|pmatrix|bmatrix|Bmatrix|vmatrix|Vmatrix)\}(.*?)\\end\{\1\}',s,re.S)
    if matrix:
        # Determinants (v/Vmatrix) are not ordinary matrices.
        if matrix[1] in ('vmatrix','Vmatrix'):raise Unsupported('DETERMINANT_NOT_MATRIX')
        rows=[split_top(r,'&') for r in re.split(r'\\\\',matrix[2])]
        if not rows or len({len(r) for r in rows})!=1:raise Unsupported('RAGGED_MATRIX')
        if sum(map(len,rows))>policy.max_container_items:raise Unsupported('CONTAINER_ITEM_LIMIT')
        return ('matrix',tuple(tuple(typed(v,policy,depth+1) for v in row) for row in rows),s)
    escaped_set=s.startswith(r'\{') and s.endswith(r'\}')
    body=s[2:-2] if escaped_set else s[1:-1]
    if s in (r'\emptyset',r'\varnothing','{}'):return ('set',(),s)
    if escaped_set or (s.startswith('{') and s.endswith('}') and len(split_top(body))>1):kind='set'
    elif len(s)>=2 and s[0] in '[(' and s[-1] in '])' and single_outer_pair(s):
        parts=split_top(body)
        if len(parts)<2:return ('scalar',(),s)
        kind=('pair_ambiguous' if len(parts)==2 else 'tuple') if s[0]=='(' and s[-1]==')' else 'interval:'+s[0]+s[-1]
        if kind.startswith('interval') and len(parts)!=2:raise Unsupported('INTERVAL_ARITY')
    else:return ('relation' if re.search(r'=|<|>|\\(?:leq?|geq?|neq?|in)\b',s) else 'scalar',(),s)
    parts=split_top(body)
    if len(parts)>policy.max_container_items:raise Unsupported('CONTAINER_ITEM_LIMIT')
    return (kind,tuple(typed(p,policy,depth+1) for p in parts),s)

def resolve_type(value,hint=None):
    kind,parts,text=value
    if kind=='pair_ambiguous':
        if hint not in ('tuple','interval'):raise Unsupported('AMBIGUOUS_PAREN_PAIR_TYPE')
        kind='tuple' if hint=='tuple' else 'interval:()'
    elif hint is not None and hint!=('interval' if kind.startswith('interval:') else kind):raise Unsupported('TYPE_HINT_SYNTAX_MISMATCH')
    if kind=='matrix':parts=tuple(tuple(resolve_type(v) for v in row) for row in parts)
    else:parts=tuple(resolve_type(v) for v in parts)
    return kind,parts,text

def rational(text):
    s=text.strip();sign=1
    if s.startswith('-'):sign=-1;s=s[1:]
    elif s.startswith('+'):s=s[1:]
    frac=re.fullmatch(r'\\frac\{([+-]?\d+)\}\{([+-]?\d+)\}',s)
    if frac:
        try:return sign*Fraction(int(frac[1]),int(frac[2]))
        except ZeroDivisionError:raise Unsupported('ZERO_DENOMINATOR')
    if re.fullmatch(r'(?:\d+(?:\.\d*)?|\.\d+)(?:/[+-]?\d+)?',s):
        try:
            parts=s.split('/',1)
            return sign*Fraction(parts[0])/(int(parts[1]) if len(parts)==2 else 1)
        except (ValueError,ZeroDivisionError):raise Unsupported('INVALID_RATIONAL')
    return None

@lru_cache(maxsize=4096)
def parse_scalar(text):
    COUNTS['parse']+=1
    from .kernel_binding import normalize_native_input
    values,valid=kernel().parse_payload(normalize_native_input(text))
    if not valid:raise Unsupported('PINNED_PARSE_UNSUPPORTED')
    # This rejects arithmetic infinities/NaN masquerading as ordinary expressions.
    from sympy import preorder_traversal,zoo,nan
    for value in values:
        if value.has(zoo,nan):raise Unsupported('UNDEFINED_EXPRESSION')
        if sum(1 for _ in preorder_traversal(value))>512:raise Unsupported('PARSED_COMPLEXITY_LIMIT')
    return values

def validate(value,reference=False):
    kind,parts,text=value
    if kind=='matrix':
        for row in parts:
            for v in row:validate(v,reference)
    elif parts:
        for v in parts:validate(v,reference)
    elif kind in ('scalar','relation'):
        try:
            number=rational(text)
            if number is None:parse_scalar(text)
        except Unsupported as exc:
            if reference and str(exc) in ('PINNED_PARSE_UNSUPPORTED','INVALID_RATIONAL','ZERO_DENOMINATOR','UNDEFINED_EXPRESSION'):raise BadReference(str(exc)) from exc
            raise

def equal(gold,prediction):
    gk,gp,gs=gold;pk,pp,ps=prediction
    if gk!=pk:return False
    if gs==ps:return True
    if gk=='matrix':
        return len(gp)==len(pp) and all(len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b)) for a,b in zip(gp,pp))
    if gk=='set':
        # Set membership ignores order and duplicates, unlike tuples/matrices.
        return all(any(equal(a,b) for b in pp) for a in gp) and all(any(equal(a,b) for a in gp) for b in pp)
    if gp or pp:return len(gp)==len(pp) and all(equal(a,b) for a,b in zip(gp,pp))
    a,b=rational(gs),rational(ps)
    if a is not None and b is not None:return a==b
    left,right=parse_scalar(gs),parse_scalar(ps)
    # Exact finite-decimal scalar pairs are handled above. General Float
    # expressions are left unresolved rather than silently rounded equal.
    from sympy import Float
    if any(v.has(Float) for v in [*left,*right]):raise Unsupported('FLOAT_EXPRESSION_NOT_EXACTLY_CERTIFIED')
    COUNTS['verify']+=1
    return bool(kernel().verify_payload(left,right))

def compare(reference,prediction,policy,*,symmetric=False,type_hints=None):
    hints=type_hints or {}
    try:gold=resolve_type(typed(reference,policy),hints.get('reference'))
    except Unsupported as exc:
        return 'UNSUPPORTED',None,str(exc)
    try:validate(gold,True)
    except BadReference as exc:return 'REFERENCE_INVALID',None,str(exc)
    except Unsupported as exc:return 'UNSUPPORTED',None,str(exc)
    try:
        predicted=resolve_type(typed(prediction,policy),hints.get('prediction'));validate(predicted)
        forward=equal(gold,predicted)
        if symmetric and forward!=equal(predicted,gold):return 'UNSUPPORTED',None,'ASYMMETRIC_PINNED_COMPARISON'
        return ('CORRECT' if forward else 'INCORRECT'),forward,'TYPED_EXACT_OR_PINNED_KERNEL'
    except Unsupported as exc:return 'UNSUPPORTED',None,str(exc)
