"""One bounded persistent worker, killed and reaped on deadline or failure."""
import atexit,json,os,queue,subprocess,sys,threading,time
from pathlib import Path

class WorkerFailure(RuntimeError):pass
class WorkerTimeout(WorkerFailure):pass

class WindowsJob:
    def __init__(self,process,memory_bytes):
        import ctypes
        from ctypes import wintypes
        class Basic(ctypes.Structure):
            _fields_=[('PerProcessUserTimeLimit',ctypes.c_int64),('PerJobUserTimeLimit',ctypes.c_int64),('LimitFlags',wintypes.DWORD),
                ('MinimumWorkingSetSize',ctypes.c_size_t),('MaximumWorkingSetSize',ctypes.c_size_t),('ActiveProcessLimit',wintypes.DWORD),
                ('Affinity',ctypes.c_size_t),('PriorityClass',wintypes.DWORD),('SchedulingClass',wintypes.DWORD)]
        class IO(ctypes.Structure):_fields_=[(n,ctypes.c_uint64) for n in ['ReadOperationCount','WriteOperationCount','OtherOperationCount','ReadTransferCount','WriteTransferCount','OtherTransferCount']]
        class Extended(ctypes.Structure):
            _fields_=[('BasicLimitInformation',Basic),('IoInfo',IO),('ProcessMemoryLimit',ctypes.c_size_t),('JobMemoryLimit',ctypes.c_size_t),('PeakProcessMemoryUsed',ctypes.c_size_t),('PeakJobMemoryUsed',ctypes.c_size_t)]
        lib=ctypes.WinDLL('kernel32',use_last_error=True)
        lib.CreateJobObjectW.restype=wintypes.HANDLE;lib.CreateJobObjectW.argtypes=[ctypes.c_void_p,wintypes.LPCWSTR]
        lib.SetInformationJobObject.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD]
        lib.AssignProcessToJobObject.argtypes=[wintypes.HANDLE,wintypes.HANDLE]
        lib.TerminateJobObject.argtypes=[wintypes.HANDLE,wintypes.UINT]
        lib.CloseHandle.argtypes=[wintypes.HANDLE]
        lib.OpenProcess.restype=wintypes.HANDLE;lib.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
        lib.IsProcessInJob.argtypes=[wintypes.HANDLE,wintypes.HANDLE,ctypes.POINTER(wintypes.BOOL)]
        lib.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD]
        self.lib=lib;self.members=[];self.handle=lib.CreateJobObjectW(None,None)
        if not self.handle:raise WorkerFailure('WINDOWS_JOB_CREATE_FAILURE')
        limits=Extended();limits.BasicLimitInformation.LimitFlags=0x00002000|0x00000100 # KILL_ON_JOB_CLOSE | PROCESS_MEMORY
        limits.ProcessMemoryLimit=memory_bytes
        if not lib.SetInformationJobObject(self.handle,9,ctypes.byref(limits),ctypes.sizeof(limits)) or not lib.AssignProcessToJobObject(self.handle,wintypes.HANDLE(int(process._handle))):
            self.close();raise WorkerFailure('WINDOWS_JOB_MEMORY_GUARD_UNAVAILABLE')
    def attach_worker(self,pid):
        import ctypes
        from ctypes import wintypes
        handle=self.lib.OpenProcess(0x100|0x1|0x1000|0x100000,False,pid)
        if not handle:raise WorkerFailure('WINDOWS_WORKER_PROCESS_HANDLE')
        included=wintypes.BOOL()
        if not self.lib.IsProcessInJob(handle,self.handle,ctypes.byref(included)) or not included.value and not self.lib.AssignProcessToJobObject(self.handle,handle):
            self.lib.CloseHandle(handle);raise WorkerFailure('WINDOWS_ACTUAL_WORKER_MEMORY_GUARD')
        self.members.append(handle)
    def close(self):
        if self.handle:
            self.lib.TerminateJobObject(self.handle,1);self.lib.CloseHandle(self.handle);self.handle=None
            for handle in self.members:
                result=self.lib.WaitForSingleObject(handle,2000);self.lib.CloseHandle(handle)
                if result!=0:raise WorkerFailure('WINDOWS_ACTUAL_WORKER_NOT_REAPED')
            self.members=[]

class Supervisor:
    def __init__(self,policy):
        self.policy=policy;self.process=None;self.job=None;self.reader=None;self.mailbox=None
        self.lock=threading.RLock();self.closed=False;self.spawned=[];self.worker_pids=[];self.terminated=[]
        atexit.register(self.close)
    def _command(self):
        return [sys.executable,'-u','-m',__package__+'.worker',str(self.policy.memory_megabytes)]
    def _read(self,process,mailbox):
        try:
            while True:
                line=process.stdout.readline(1_048_577)
                if not line:mailbox.put(WorkerFailure('WORKER_EXITED'));return
                if len(line)>1_048_576:mailbox.put(WorkerFailure('WORKER_RESPONSE_LIMIT'));return
                mailbox.put(json.loads(line))
        except Exception:mailbox.put(WorkerFailure('WORKER_PROTOCOL_FAILURE'))
    def _receive(self,seconds):
        try:value=self.mailbox.get(timeout=seconds)
        except queue.Empty:raise WorkerTimeout('EVALUATOR_WALL_DEADLINE') from None
        if isinstance(value,Exception):raise value
        return value
    def _start(self):
        env={k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ('API_KEY','TOKEN','SECRET','PASSWORD','CREDENTIAL','AUTHORIZATION','BASE_URL'))}
        env.update(PYTHONIOENCODING='utf-8',PYTHONUTF8='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
        own_package_parent=str(Path(__file__).resolve().parents[2])
        env['PYTHONPATH']=own_package_parent+(os.pathsep+env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
        self.process=subprocess.Popen(self._command(),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
            env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        self.spawned.append(self.process.pid)
        if os.name=='nt':self.job=WindowsJob(self.process,self.policy.memory_megabytes*1024*1024)
        self.mailbox=queue.Queue();self.reader=threading.Thread(target=self._read,args=(self.process,self.mailbox),daemon=True);self.reader.start()
        ready=self._receive(self.policy.startup_seconds)
        if ready.get('ready') is not True or type(ready.get('pid')) is not int:raise WorkerFailure('WORKER_STARTUP_PROTOCOL')
        if os.name=='nt':self.job.attach_worker(ready['pid'])
        elif ready['pid']!=self.process.pid:raise WorkerFailure('WORKER_STARTUP_PID_MISMATCH')
        self.worker_pids.append(ready['pid'])
    def request(self,payload):
        with self.lock:
            if self.closed:raise WorkerFailure('SCORER_CLOSED')
            try:
                if self.process is None or self.process.poll() is not None:self._stop();self._start()
                data=(json.dumps(payload,ensure_ascii=True,separators=(',',':'))+'\n').encode('ascii')
                self.process.stdin.write(data);self.process.stdin.flush()
                result=self._receive(self.policy.wall_seconds)
                if not isinstance(result,dict) or result.get('input_sha256')!=payload['input_sha256']:raise WorkerFailure('WORKER_INPUT_ECHO_MISMATCH')
                return result
            except WorkerTimeout:
                self._stop();raise
            except (WorkerFailure,OSError,ValueError,TypeError) as exc:
                self._stop()
                if isinstance(exc,WorkerFailure):raise
                raise WorkerFailure('WORKER_INFRASTRUCTURE_FAILURE') from exc
    def _stop(self):
        p=self.process;self.process=None
        if self.job is not None:self.job.close();self.job=None
        if p is not None:
            if p.poll() is None:p.kill()
            try:p.wait(timeout=2)
            except subprocess.TimeoutExpired:raise WorkerFailure('WORKER_COULD_NOT_BE_REAPED')
            for stream in (p.stdin,p.stdout):
                if stream:
                    try:stream.close()
                    except OSError:pass
            self.terminated.append(p.pid)
        if self.reader is not None:
            self.reader.join(timeout=1)
            if self.reader.is_alive():raise WorkerFailure('WORKER_READER_NOT_REAPED')
            self.reader=None
    def close(self):
        with self.lock:
            self._stop();self.closed=True
